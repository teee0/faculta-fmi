data Fuel a = Fuel {getFuel :: Integer -> Maybe (Integer, a)}

instance Functor Fuel where
     fmap f (Fuel m) =
         Fuel
            (\i ->
                 case m i of
                   Nothing -> Nothing
                   Just (i', a) -> Just (i', f a)
            )

instance Applicative Fuel where
     pure x = Fuel (\i -> Just (i, x))
     
     (Fuel mf) <*> (Fuel af) =
         Fuel (\i ->
                   case mf i of
                     Nothing -> Nothing
                     Just (i', f) ->
                         if i' <= 0
                         then Nothing
                         else case af (i' - 1) of
                                Nothing -> Nothing
                                Just (i'', a) ->
                                        if i'' <= 0
                                        then Nothing
                                        else Just (i'' - 2, f a)
              )


instance Monad Fuel where
     (Fuel fa) >>= f =
         Fuel
         (\i ->
              case fa i of
                Nothing -> Nothing
                Just (i', a) ->
                 if i' <= 0
                 then Nothing
                 else getFuel (f a) (i' - 1)
         )

test :: Fuel Int
test = pure 0 >>= pure . (+1) >>= pure . (+1)

failEx = getFuel test 1
sucEx = getFuel test 2

