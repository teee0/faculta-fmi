newtype Reader env a = Reader { runReader :: env -> a }
-- runReader : : Reader env a −> env −> a

instance Monad (Reader env) where
  return x = Reader (\_ -> x)
  ma >>= k = Reader f
    where f env = let a = runReader ma env
                  in  runReader (k a) env

instance Applicative (Reader env) where
  pure = return
  mf <*> ma = do
    f <- mf
    a <- ma
    return (f a)       

instance Functor (Reader env) where              
  fmap f ma = pure f <*> ma     

ask :: Reader env env
ask = Reader id

tom :: Reader String String
tom = do
  env <- ask -- gives the environment (here a String)
  return (env ++ " This is Tom.")

jerry :: Reader String String
jerry = do
    env <- ask
    return (env ++ " This is Jerry.")
    
tomAndJerry :: Reader String String
tomAndJerry = do
   t <- tom
   j <- jerry
   return (t ++ "\n " ++ j)

runJerryRun :: String
runJerryRun = runReader tomAndJerry "Who is this?"


